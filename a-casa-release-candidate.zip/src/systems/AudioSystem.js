import { SETTINGS } from './SettingsSystem.js';

const SCENE_AUDIO = {
  TitleScene: { music: 'music_theme', musicVolume: 0.65 },
  RoomScene: { music: 'music_routine', musicVolume: 0.32 },
  KitchenScene: { music: 'music_routine', musicVolume: 0.28, ambience: 'fridge_hum', ambienceVolume: 0.42 },
  GarageScene: { music: 'music_routine', musicVolume: 0.24 },
  BedroomScene: { music: 'music_routine', musicVolume: 0.18 },
  DanielRoomScene: { music: 'music_routine', musicVolume: 0.18 },
  YardScene: { music: 'music_yard', musicVolume: 0.52, ambience: 'yard_ambience', ambienceVolume: 0.55 },
  MemoryScene: { music: 'music_memories', musicVolume: 0.58 },
  DinnerMemoryScene: { music: 'music_memories', musicVolume: 0.5 },
  WorkshopMemoryScene: { music: 'music_memories', musicVolume: 0.46 },
  ArgumentMemoryScene: { music: 'music_memories', musicVolume: 0.32 },
  DrawingMemoryScene: { music: 'music_memories', musicVolume: 0.42 },
  ReinterpretationScene: { music: 'music_memories', musicVolume: 0.24 },
  ClosingScene: { music: 'music_farewell', musicVolume: 0.6 },
  EndScene: { music: 'music_farewell', musicVolume: 0.42 },
  EpilogueScene: { music: 'music_epilogue', musicVolume: 0.58 },
};

export default class AudioSystem {
  constructor(scene) {
    this.scene = scene;
    this.music = null;
    this.ambience = null;
    this.musicLocal = 1;
    this.ambienceLocal = 1;
    this.lastStepAt = 0;
  }

  volume(channel, local = 1) {
    const master = Number(SETTINGS.masterVolume ?? 1);
    const level = Number(SETTINGS[channel] ?? 1);
    return Math.max(0, Math.min(1, master * level * local));
  }

  playSfx(key, config = {}, caption = null) {
    if (!this.scene.cache.audio.exists(key)) return null;
    const volume = this.volume('sfxVolume', config.volume ?? 1);
    const sound = this.scene.sound.add(key, { ...config, volume });
    try { sound.play(); } catch {}
    if (caption) window.ACasaUI?.captionSound(caption);
    sound.once?.('complete', () => sound.destroy());
    return sound;
  }

  playMusic(key, config = {}) {
    if (!this.scene.cache.audio.exists(key)) return null;
    this.stopMusic();
    this.musicLocal = config.volume ?? 1;
    const volume = this.volume('musicVolume', this.musicLocal);
    this.music = this.scene.sound.add(key, { loop: config.loop ?? true, ...config, volume });
    try { this.music.play(); } catch {}
    return this.music;
  }

  playAmbience(key, config = {}, caption = null) {
    if (!this.scene.cache.audio.exists(key)) return null;
    this.stopAmbience();
    this.ambienceLocal = config.volume ?? 1;
    const volume = this.volume('ambienceVolume', this.ambienceLocal);
    this.ambience = this.scene.sound.add(key, { loop: config.loop ?? true, ...config, volume });
    try { this.ambience.play(); } catch {}
    if (caption) window.ACasaUI?.captionSound(caption);
    return this.ambience;
  }

  setupForScene() {
    const profile = SCENE_AUDIO[this.scene.scene.key];
    if (!profile) return;
    if (profile.music) this.playMusic(profile.music, { loop: true, volume: profile.musicVolume ?? 1 });
    if (profile.ambience) this.playAmbience(profile.ambience, { loop: true, volume: profile.ambienceVolume ?? 1 });
  }

  footstep(surface = 'wood') {
    const now = performance.now();
    if (now - this.lastStepAt < 300) return;
    this.lastStepAt = now;
    const keys = surface === 'tile' ? ['step_tile'] : surface === 'concrete' ? ['step_concrete'] : ['step_wood_1','step_wood_2'];
    const key = keys[Math.floor(Math.random() * keys.length)];
    this.playSfx(key, { volume: 0.38, rate: 0.96 + Math.random() * 0.08 });
  }

  refreshVolumes() {
    if (this.music) this.music.setVolume(this.volume('musicVolume', this.musicLocal));
    if (this.ambience) this.ambience.setVolume(this.volume('ambienceVolume', this.ambienceLocal));
  }

  stopMusic() { if (this.music) { this.music.stop(); this.music.destroy(); } this.music = null; }
  stopAmbience() { if (this.ambience) { this.ambience.stop(); this.ambience.destroy(); } this.ambience = null; }
  destroy() { this.stopMusic(); this.stopAmbience(); }
}
