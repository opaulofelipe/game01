import { SETTINGS, setSetting, resetSettings, applySettingsToDocument } from '../systems/SettingsSystem.js';
import { SAVE, saveGame, resetSave } from '../systems/SaveSystem.js';

class UIOverlay {
  constructor(game) {
    this.game = game;
    this.root = document.getElementById('ui-overlay');
    this.panel = document.getElementById('ui-panel');
    this.caption = document.getElementById('sound-caption');
    this.orientation = document.getElementById('orientation-hint');
    this.activeScene = null;
    this.sceneWasPaused = false;
    this.hideTimer = null;

    this.root.addEventListener('click', (e) => {
      if (e.target === this.root) this.close();
      const action = e.target?.dataset?.action;
      if (!action) return;
      this.handleAction(action);
    });

    window.addEventListener('acasa-saved', () => this.showSaveIndicator());
    window.addEventListener('resize', () => this.updateOrientationHint());
    window.addEventListener('orientationchange', () => setTimeout(() => this.updateOrientationHint(), 100));
    applySettingsToDocument();
    this.updateOrientationHint();
  }

  getScene() {
    return this.activeScene || this.game.scene.getScenes(true).at(-1) || null;
  }

  pauseScene(scene) {
    if (!scene || scene.scene.key === 'TitleScene') return;
    if (!scene.scene.isPaused()) {
      scene.scene.pause();
      this.sceneWasPaused = true;
    }
  }

  resumeScene() {
    const scene = this.activeScene;
    if (scene && this.sceneWasPaused && scene.scene.isPaused()) scene.scene.resume();
    this.sceneWasPaused = false;
  }

  togglePause(scene) {
    if (this.root.classList.contains('is-open')) {
      this.close();
      return;
    }
    this.openPause(scene);
  }

  openPause(scene = this.getScene()) {
    this.activeScene = scene;
    this.pauseScene(scene);
    this.renderPause();
    this.open();
  }

  openSettings(scene = this.getScene(), pause = true) {
    this.activeScene = scene;
    if (pause) this.pauseScene(scene);
    this.renderSettings();
    this.open();
  }

  openControls(scene = this.getScene(), pause = true) {
    this.activeScene = scene;
    if (pause) this.pauseScene(scene);
    this.panel.innerHTML = `
      <div class="overlay-head"><span>CONTROLES</span><button data-action="close" aria-label="Fechar">×</button></div>
      <div class="controls-grid">
        <div><b>WASD / Setas</b><span>Mover</span></div>
        <div><b>E / Espaço / Enter</b><span>Interagir / avançar</span></div>
        <div><b>← / →</b><span>Escolher opção</span></div>
        <div><b>Esc</b><span>Pausar</span></div>
        <div><b>Touch</b><span>Direcional + botão E</span></div>
      </div>
      <button class="menu-button" data-action="back">Voltar</button>`;
    this.open();
  }

  openHistory(scene = this.getScene(), pause = true) {
    this.activeScene = scene;
    if (pause) this.pauseScene(scene);
    const history = (SAVE.dialogueHistory || []).slice(-30).reverse();
    const items = history.length ? history.map((h) => `<div class="history-item"><b>${this.escape(h.kicker || '—')}</b><span>${this.escape(h.text)}</span></div>`).join('') : '<p class="muted">Ainda não há falas no histórico.</p>';
    this.panel.innerHTML = `
      <div class="overlay-head"><span>HISTÓRICO</span><button data-action="close" aria-label="Fechar">×</button></div>
      <div class="history-list">${items}</div>
      <button class="menu-button" data-action="back">Voltar</button>`;
    this.open();
  }

  openCredits(scene = this.getScene(), pause = false) {
    this.activeScene = scene;
    if (pause) this.pauseScene(scene);
    this.panel.innerHTML = `
      <div class="overlay-head"><span>CRÉDITOS</span><button data-action="close" aria-label="Fechar">×</button></div>
      <div class="credits-copy">
        <h2>A CASA</h2>
        <p>Jogo narrativo curto sobre luto, memória e despedida.</p>
        <p><b>Conceito, narrativa e direção:</b> projeto desenvolvido em colaboração com o jogador.</p>
        <p><b>Programação e sistemas:</b> JavaScript + Phaser.</p>
        <p><b>Arte:</b> direção visual original em pixel-art estilizada.</p>
        <p><b>Áudio:</b> efeitos e trilha instrumental original produzidos para o projeto.</p>
        <p class="muted">Pessoas comuns. Histórias reais.</p>
      </div>
      <button class="menu-button" data-action="close">Voltar</button>`;
    this.open();
  }

  renderPause() {
    this.panel.innerHTML = `
      <div class="overlay-head"><span>PAUSA</span><button data-action="close" aria-label="Fechar">×</button></div>
      <button class="menu-button primary" data-action="resume">Continuar</button>
      <button class="menu-button" data-action="settings">Configurações</button>
      <button class="menu-button" data-action="controls">Controles</button>
      <button class="menu-button" data-action="history">Histórico</button>
      <button class="menu-button" data-action="menu">Voltar ao menu</button>`;
  }

  renderSettings() {
    const checked = (v) => v ? 'checked' : '';
    const option = (value, label, current) => `<option value="${value}" ${current === value ? 'selected' : ''}>${label}</option>`;
    this.panel.innerHTML = `
      <div class="overlay-head"><span>CONFIGURAÇÕES</span><button data-action="close" aria-label="Fechar">×</button></div>
      <div class="settings-scroll">
        <h3>Áudio</h3>
        ${this.slider('masterVolume','Volume geral',SETTINGS.masterVolume)}
        ${this.slider('musicVolume','Música',SETTINGS.musicVolume)}
        ${this.slider('ambienceVolume','Ambiente',SETTINGS.ambienceVolume)}
        ${this.slider('sfxVolume','Efeitos',SETTINGS.sfxVolume)}
        <h3>Texto</h3>
        <label class="setting-row"><span>Tamanho</span><select data-setting="textSize">${option('medium','Médio',SETTINGS.textSize)}${option('large','Grande',SETTINGS.textSize)}${option('xlarge','Muito grande',SETTINGS.textSize)}</select></label>
        <label class="setting-row"><span>Velocidade</span><select data-setting="textSpeed">${option('slow','Lenta',SETTINGS.textSpeed)}${option('normal','Normal',SETTINGS.textSpeed)}${option('fast','Rápida',SETTINGS.textSpeed)}${option('instant','Instantânea',SETTINGS.textSpeed)}</select></label>
        ${this.toggle('readableFont','Fonte de alta legibilidade',checked(SETTINGS.readableFont))}
        ${this.toggle('highContrast','Contraste elevado',checked(SETTINGS.highContrast))}
        <h3>Acessibilidade</h3>
        ${this.toggle('soundCaptions','Legendas de sons',checked(SETTINGS.soundCaptions))}
        ${this.toggle('reducedMotion','Reduzir movimento',checked(SETTINGS.reducedMotion))}
        ${this.toggle('reducedEffects','Reduzir efeitos ambientais',checked(SETTINGS.reducedEffects))}
        ${this.toggle('visibleInteractions','Interações mais visíveis',checked(SETTINGS.visibleInteractions))}
        ${this.toggle('showObjectives','Mostrar objetivos',checked(SETTINGS.showObjectives))}
        ${this.toggle('navigationHelp','Ajuda de navegação',checked(SETTINGS.navigationHelp))}
        <h3>Controles móveis</h3>
        <label class="setting-row"><span>Lado do direcional</span><select data-setting="touchSide">${option('right','Padrão',SETTINGS.touchSide)}${option('left','Canhoto',SETTINGS.touchSide)}</select></label>
        ${this.slider('touchOpacity','Opacidade',SETTINGS.touchOpacity)}
      </div>
      <div class="settings-actions"><button class="menu-button" data-action="reset-settings">Restaurar padrão</button><button class="menu-button primary" data-action="back">Voltar</button></div>`;

    this.panel.querySelectorAll('[data-setting]').forEach((el) => {
      const event = el.type === 'range' ? 'input' : 'change';
      el.addEventListener(event, () => {
        let value = el.type === 'checkbox' ? el.checked : el.value;
        if (el.type === 'range') value = Number(value);
        setSetting(el.dataset.setting, value);
      });
    });
  }

  slider(key, label, value) {
    return `<label class="setting-row slider-row"><span>${label}</span><input type="range" min="0" max="1" step="0.01" value="${value}" data-setting="${key}" aria-label="${label}"></label>`;
  }

  toggle(key, label, checked) {
    return `<label class="setting-row"><span>${label}</span><input type="checkbox" data-setting="${key}" ${checked}></label>`;
  }

  handleAction(action) {
    if (action === 'close' || action === 'resume') return this.close();
    if (action === 'settings') return this.openSettings(this.activeScene, false);
    if (action === 'controls') return this.openControls(this.activeScene, false);
    if (action === 'history') return this.openHistory(this.activeScene, false);
    if (action === 'back') {
      if (this.activeScene?.scene?.key === 'TitleScene') return this.close();
      this.renderPause();
      return;
    }
    if (action === 'reset-settings') { resetSettings(); this.renderSettings(); return; }
    if (action === 'menu') {
      saveGame();
      const scene = this.activeScene;
      this.close(false);
      if (scene) { scene.scene.stop(); scene.scene.start('TitleScene'); }
      return;
    }
  }

  open() {
    this.root.classList.add('is-open');
    this.root.setAttribute('aria-hidden','false');
    this.panel.querySelector('button,select,input')?.focus();
  }

  close(resume = true) {
    this.root.classList.remove('is-open');
    this.root.setAttribute('aria-hidden','true');
    if (resume) this.resumeScene();
    this.activeScene = null;
  }

  showSaveIndicator() {
    const el = document.getElementById('save-indicator');
    if (!el) return;
    el.classList.add('show');
    clearTimeout(this.saveTimer);
    this.saveTimer = setTimeout(() => el.classList.remove('show'), 900);
  }

  captionSound(text) {
    if (!SETTINGS.soundCaptions || !text) return;
    this.caption.textContent = `[${text}]`;
    this.caption.classList.add('show');
    clearTimeout(this.hideTimer);
    this.hideTimer = setTimeout(() => this.caption.classList.remove('show'), 1800);
  }

  updateOrientationHint() {
    const coarse = matchMedia('(pointer: coarse)').matches;
    const portrait = innerHeight > innerWidth;
    if (coarse && portrait && !sessionStorage.getItem('a-casa-orientation-hint')) {
      this.orientation.classList.add('show');
    } else {
      this.orientation.classList.remove('show');
    }
  }

  dismissOrientation() {
    sessionStorage.setItem('a-casa-orientation-hint','1');
    this.orientation.classList.remove('show');
  }

  escape(value='') {
    return String(value).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  }
}

export function initUIOverlay(game) {
  const ui = new UIOverlay(game);
  window.ACasaUI = ui;
  document.getElementById('orientation-continue')?.addEventListener('click', () => ui.dismissOrientation());
  return ui;
}
